... only a short note:

Since version 3.1 even the traybar icons are customizable. If you
like,  create  your  own  design  and  send it to me. I will then
include it in all future versions of Yamp.

Thanx a lot ;)